# J.A.R.V.I.S. — App (PWA)

Pasta pronta para publicar no **GitHub Pages**. Depois de instalado no celular, abre **sem barra do navegador**.

## Arquivos

- `index.html` — app
- `manifest.webmanifest` — definição do app
- `sw.js` — service worker
- `icon-192.png` / `icon-512.png` / `apple-touch-icon.png` — ícones

## Publicar no GitHub Pages

1. Envie **todos** os arquivos desta pasta para o repositório (raiz ou pasta `docs`).
2. Em **Settings → Pages**, ative GitHub Pages.
3. Abra o site no celular (Chrome/Edge/Safari).

## Instalar como app

### Android (Chrome)
1. Abra o site
2. Menu **⋮ → Instalar app** (ou use **Instalar app** no menu do J.A.R.V.I.S.)
3. Abra pelo ícone na tela inicial — **sem barra de URL**

### iPhone (Safari)
1. Abra no **Safari**
2. **Compartilhar → Adicionar à Tela de Início**
3. Abra pelo ícone

## Importante

- Precisa de **HTTPS** (GitHub Pages já fornece).
- Service worker só funciona em origem segura (`https://` ou `localhost`).
